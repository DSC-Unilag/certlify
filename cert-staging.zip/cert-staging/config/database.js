module.exports = {
  database:
    "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass%20Community&ssl=false",
  secret: "secret-key",
};
